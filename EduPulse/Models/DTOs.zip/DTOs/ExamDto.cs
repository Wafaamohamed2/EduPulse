﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EduPulse.Models.DTOs
{
    public class ExamDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Exam name is required")]
        [JsonPropertyName("examName")]
        public string ExamName { get; set; } = string.Empty;

        [JsonPropertyName("timeLimitInMinutes")]
        public int TimeLimitInMinutes { get; set; }

        [Required(ErrorMessage = "Google Form link is required")]
        [JsonPropertyName("googleFormLink")] 
        public string GoogleFormLink { get; set; } = string.Empty;

        [JsonPropertyName("deadlineDate")]
        public DateTime DeadlineDate { get; set; }

        [JsonPropertyName("subjectId")] 
        public int? SubjectId { get; set; }
    }
}
