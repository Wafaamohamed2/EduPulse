﻿namespace EduPulse.Models.DTOs
{
    public class UserDeviceDto
    {
        public string DeviceToken { get; set; } = string.Empty;
       // public string? FingerprintId { get; set; }
    }
}
